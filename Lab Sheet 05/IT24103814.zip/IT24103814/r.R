setwd("D:\\SLIIT\\2nd year\\1st sem\\Probability and Statistics - IT2120\\lab\\lab5\\IT24103814")
getwd()

data<-read.table("Data.txt",header=TRUE,sep=",")

fix(data)

attach(data)

names(data)<-c("X1","X2")
attach(data)

hist(X2,main="Histogram for Number of Shareholders")

hist(X2,main="Histogram for Number of Shareholders",breaks = seq(130, 270,length=8),right=FALSE)
histogram<-hist(X2,main="Histogram for Number of Shareholders",breaks = seq(130, 270,length=8),right=FALSE)

breaks<-round(histogram$counts)
breaks


freq<-histogram$counts
freq

mids<-histogram$mids
mids

classes <- c()

for(i in 1:length(breaks)-1){
  classes[i]<- paste0("[",breaks[i],",",breaks[i+1],")")
}
classes


cbind(classes=classes,Frequency=freq)

lines(mids,freq)


plot(mids, freq, type='l', main="Frequency Polygon for Shareholders", xlab="Shareholders", ylab="Frequency", ylim=c(0, max(freq)))

cum.freq<- cumsum(freq)

new<-c()

for(i in 1:length(breaks)){
  if (i==1){
    new[i]=0
  }else{
    new[i]= cum.freq[i-1]
  }
}

plot(breaks,new,type='l',main = "Cumalative Frequency Polygon for Shreholders",
     xlab ="shareholders",ylab="Cumalative Frequency",ylim=c(0,max(cum.freq)))

cbind(Upper=breaks,CumFreq=new)




# Load data
delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

# Extract the column (note: column name has parentheses and underscores)
time_values <- as.numeric(delivery_Times$Delivery_Time_(minutes))   # ❌ this won't work directly


time_values <- as.numeric(delivery_Times[["Delivery_Time_(minutes)"]])

# Check the values
summary(time_values)

# Plot histogram
hist(time_values,
     main = "Histogram for Delivery Times",
     xlab = "Delivery Time (minutes)",
     col = "lightblue",
     border = "black",
     breaks = seq(20, 70, by = 5))   # cut into 5-minute intervals


# Read data
delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

# Extract values (handling special column name with [])
time_values <- delivery_Times[["Delivery_Time_(minutes)"]]

# Create class intervals (5-minute bins from 20 to 70)
breaks <- seq(20, 70, by = 5)

# Frequency table
freq <- table(cut(time_values, breaks = breaks, right = FALSE))

# Cumulative frequency
cum_freq <- cumsum(freq)

# Midpoints of intervals
midpoints <- breaks[-length(breaks)] + diff(breaks)/2

# Plot cumulative frequency polygon (ogive)
plot(midpoints, cum_freq,
     type = "o", col = "blue", pch = 16,
     main = "Cumulative Frequency Polygon (Ogive) for Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency")

